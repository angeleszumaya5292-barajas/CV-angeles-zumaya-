# CV de Angeles Zumaya 🎮

Currículum Vitae en HTML y CSS con una temática inspirada en Pac-Man.

## Datos
- **Nombre:** Angeles Zumaya
- **Carrera:** Ingeniería en Negocios
- **Universidad:** Universidad de Guadalajara
- **Correo:** angeleszumayabarajas@gmail.com

## Archivos
- `index.html` — página principal del CV.
- `style.css` — estilos, diseño y animaciones.

## Ver el proyecto
Este proyecto está preparado para publicarse con **GitHub Pages**. El archivo principal debe llamarse `index.html`.
